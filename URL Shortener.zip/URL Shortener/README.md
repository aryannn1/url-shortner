
# URL-Shortener

A simple and fast URL shortener! This allows to convert long URLs into shorter, more manageable links, making them easier to share, tweet, or send via email.

Shortens long URLs using pyshorteners

🎨 Responsive UI with Bootstrap

📄 Stores and displays shortened URLs

🖼️ Custom background image support

⚙️ Built with Django 5.1.1

🛠️ Technologies Used
Backend: Django 5.1.1, Python 3

Frontend: HTML, Bootstrap 5

Library: pyshorteners, requests

Database: SQLite (default)
